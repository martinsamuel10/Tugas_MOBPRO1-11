package org.d3rpla4404.galerihewan

data class Hewan(
    val nama: String,
    val namaLatin: String,
    val imageResId: Int
)